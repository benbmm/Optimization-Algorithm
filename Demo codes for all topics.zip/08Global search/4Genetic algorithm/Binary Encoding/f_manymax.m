function y=f_manymax(x);

y=-15*(sin(2*x))^2-(x-2)^2+160;