function y=f_wave(x);

y=x(1)*sin(x(1)) + x(2)*sin(5*x(2));