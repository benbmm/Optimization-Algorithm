function radsqr = disk(x)
radsqr = x(1)^2+x(2)^2