function [c,ceq] = unitdisk(x)

c = x(1)^2 + x(2)^2 - 1;
ceq = [ ];